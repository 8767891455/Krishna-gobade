package com.Tuljabhavani.ComputerScience;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ComputerScienceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ComputerScienceApplication.class, args);
	}

}
