package com.Tuljabhavani.ComputerScience;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ComputerScienceApplicationTests {

	@Test
	void contextLoads() {
	}

}
